

設定檔
-------------------------------------------------------------------------------
拍賣API連線設定檔案		config/api.ini
Yahoo拍賣帳號設定檔案		config/yahoo_acocunt.ini
上傳欄位參考檔				config/field.ini

